/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lojaesportesss;

import java.util.ArrayList;

public class Carrinho {
    public static ArrayList<ItemCarrinho> itens = new ArrayList<>();
}